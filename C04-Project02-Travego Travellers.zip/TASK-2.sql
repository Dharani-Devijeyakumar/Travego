-- TASK 2. (Medium) Perform read operation on the designed table created in the above task.
use Travego;


select * from passenger;
select * from price;


-- a. How many female passengers traveled a minimum distance of 600 KMs? (1 mark)
select count(Gender) as Female_MinimumDistance_600KM from passenger
where gender = 'F' and distance >= 600;
-- to see entire details of those passengers.
select *,count(gender) over() as Female_MinimumDistance_600KM from passenger
where gender = 'F' and distance >= 600;
-- b. Write a query to display the passenger details whose travel distance is greater than 500 and
-- who are traveling in a sleeper bus. (2 marks)
select * from passenger 
where Distance > 500 and Bus_Type = 'Sleeper';



-- c. Select passenger names whose names start with the character 'S'.(2 marks)
select passenger_name from passenger
where passenger_name like 'S%';

-- d. Calculate the price charged for each passenger, displaying the Passenger name, Boarding City,
-- Destination City, Bus type, and Price in the output. (3 marks)


select pass.passenger_name,pass.Boarding_City,pass.Destination_City,pass.Bus_Type,pri.price
from passenger as pass join price as pri on 
pass.distance = pri.distance and pass.bus_type =pri.bus_type;


-- e. What are the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in
-- a bus? (4 marks)
select pass.passenger_name,pass.Bus_Type,pass.Distance,pri.price
from passenger as pass join price as pri on 
pass.distance = pri.distance and pass.bus_type =pri.bus_type
where pass.Distance = 1000 and pass.Bus_Type = 'Sitting';


-- f. What will be the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji? (5
-- marks)
select pass.passenger_name,pass.Boarding_City,pass.Destination_City,pass.bus_type,pass.distance,pri.price
from passenger as pass join price as pri 
on pass.distance = pri.distance and pass.bus_type =pri.bus_type
where pass.passenger_name = 'Pallavi' 
union
select 'Pallavi', 'Bengaluru','Panaji',bus_type,distance,price from price
where bus_type = 'sitting' and distance = 600;

/* 
In the passenger table, Pallavi traveled a distance of 600km from Panaji to Bangalore in a sleeper bus, 
and the cost for the journey was 1320. The entry for Pallavi is available only for the sleeper bus. 
Based on this, I made the following assumption to display the results: 
In the price table, for a bus type of 'sitting' and a distance of 600 km, the mentioned price is 744. 
I assume that in the price table, the bus type 'sitting' and a distance of 600 km corresponds to the route from Bangalore to Panaji 
because the given distance for Panaji to Bangalore is 600 km.
 To display the results, I will use a UNION statement.*/



-- g. Alter the column category with the value "Non-AC" where the Bus_Type is sleeper (2 marks)
update passenger
set category = 'Non-AC'
where bus_type = 'sleeper';

select * from passenger;

-- h. Delete an entry from the table where the passenger name is Piyush and commit this change in
-- the database. (1 mark)
/* In the default setting, autocommit is set to 1, so any changes made will be directly committed to the database itself. 
If autocommit is set to 0, then the 'commit' statement is used to commit changes in the database. */
select @@autocommit;
set autocommit = 0;
delete from passenger
where passenger_name = 'Piyush';
commit;
set autocommit = 1;
-- i. Truncate the table passenger and comment on the number of rows in the table (explain if
-- required). (1 mark)
truncate passenger;
select * from passenger;
/* after truncating the table ,there is 0 rows in the table
the function of truncate it removes all the entries from table but  the structure of the
table remains intact.*/

-- j. Delete the table passenger from the database. (1 mark)
drop table passenger;
show tables;






